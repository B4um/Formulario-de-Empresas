package leonardobaum_2bi;

import java.util.ArrayList;
import java.util.List;

public class Corporacao {
    private int id;
    private String nome;
    private String fundador;
    private List<Subsidiaria> listaSubsidiarias;

    public Corporacao(){
        this.listaSubsidiarias = new ArrayList();
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
        public String getFundador() {
        return fundador;
    }

    public void setFundador(String fundador) {
        this.fundador = fundador;
    }
    
    public List<Subsidiaria> getListaSubsidiarias(){
        return listaSubsidiarias;
    }
    
    public void addSubsidiaria(Subsidiaria s){
        this.listaSubsidiarias.add(s);
    }
    
        public void excluirSubsidiaria(Subsidiaria s){
        this.listaSubsidiarias.remove(s);
    }
        
    @Override
      public boolean equals(Object obj){
          Corporacao c = (Corporacao) obj;
          return this.id == c.getId();
      }
}
