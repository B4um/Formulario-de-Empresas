package leonardobaum_2bi;

public class LeonardoBaum_2Bi {

    /* - Criar um projeto no NetBeans, que contenha pelo menos 3 classes relacionadas (associadas),
    sendo que uma das relações seja de 1 para muitos.
    
    Ex: Cliente - Venda - Produto
    
    -Criar uma classe "controla", com uma lista para armazenar os cadastros feitos.
    */
    
    public static void main(String[] args) {
        
    }
    
}
