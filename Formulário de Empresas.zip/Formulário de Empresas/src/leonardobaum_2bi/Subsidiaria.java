package leonardobaum_2bi;

public class Subsidiaria {
    
    private String subsidiaria;
    private String fundaçao;
    private String sede;

    public String getSubsidiaria() {
        return subsidiaria;
    }

    public void setSubsidiaria(String subsidiaria) {
        this.subsidiaria = subsidiaria;
    }

    public String getFundaçao() {
        return fundaçao;
    }

    public void setFundaçao(String fundaçao) {
        this.fundaçao = fundaçao;
    }

    public String getSede() {
        return sede;
    }

    public void setSede(String sede) {
        this.sede = sede;
    }
    
    @Override
    public boolean equals(Object obj){
        Subsidiaria s = (Subsidiaria) obj;
        return this.subsidiaria.equals(s.getSubsidiaria());
    }
}
