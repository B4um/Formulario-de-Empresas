
package leonardobaum_2bi;

import java.util.ArrayList;
import java.util.List;

public class ControlaCorporaçao {
    
    private List<Corporacao> listaCorporaçoes;
    
    public ControlaCorporaçao(){
        this.listaCorporaçoes = new ArrayList();
    }
    
    public void addCorporaçao(Corporacao c){
        this.listaCorporaçoes.add(c);
    }
    
    public List<Corporacao> getListaCorporacoes(){
        return this.listaCorporaçoes;
    }
    
    public Corporacao getCorporaçao(int idCorporaçao){
        
        Corporacao retornaCorporaçao = null;
        
        for(Corporacao c : this.listaCorporaçoes){
            if(c.getId() == idCorporaçao){
                retornaCorporaçao = c;
                break;
            }
        }
        return retornaCorporaçao;
    }
}
